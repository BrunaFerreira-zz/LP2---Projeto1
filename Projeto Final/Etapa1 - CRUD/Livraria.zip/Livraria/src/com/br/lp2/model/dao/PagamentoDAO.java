/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.lp2.model.dao;

import com.br.lp2.model.Pagamento;
import java.sql.Connection;
import java.util.List;

/**
 *
 * @author Bruna
 */
public class PagamentoDAO implements GenericDAO<Pagamento>{
    private Connection conn;

    public PagamentoDAO() {
    }

    @Override
    public boolean insert(Pagamento pagamento) {
        
    }

    @Override
    public List<Pagamento> read() {
       
    }

    @Override
    public boolean update(Pagamento pagamento) {
       
    }

    @Override
    public boolean delete(Pagamento pagamento) {
        
    }
    
    
}
