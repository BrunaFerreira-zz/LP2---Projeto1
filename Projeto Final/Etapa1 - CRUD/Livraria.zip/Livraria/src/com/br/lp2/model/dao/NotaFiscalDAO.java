/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.lp2.model.dao;

import com.br.lp2.model.NotaFiscal;
import java.sql.Connection;
import java.util.List;

/**
 *
 * @author Bruna
 */
public class NotaFiscalDAO implements GenericDAO<NotaFiscal>{
    private Connection conn;

    public NotaFiscalDAO() {
    }
    

    @Override
    public boolean insert(NotaFiscal notaFiscal) {
        
    }

    @Override
    public List<NotaFiscal> read() {
       
    }

    @Override
    public boolean update(NotaFiscal notaFiscal) {
        
    }

    @Override
    public boolean delete(NotaFiscal notaFiscal) {
        
    }
}
